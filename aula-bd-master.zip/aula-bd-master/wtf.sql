create trigger tg1 after update
on professor 
for each row
begin
	if (new.senhaprofessor != old.senhaprofessor) then
		insert into log (descricaolog) values (concat ('Foi alterada a senha do professor: ', new.nomeprofessor));
	end if;
end;

create trigger tg2 after update
on aluno
for each row
begin
	if (new.statusaluno != old.statusaluno) then
		insert into log (descricaolog) values (concat ('Foi alterado o status do aluno: ', new.nomealuno));
	end if;
end;

create trigger tg3 after insert
on turma
for each row
begin
	insert into log (descricaolog) values (concat ('Foi adicionada uma turma: ', new.nometurma));
end;

create trigger tg4 after insert
on nota
for each row
begin
	insert into log (descricaolog) values (
		concat(
			'Foi adicionada a nota 1sem: ', new.nota1semestre, 
			', nota 2sem: ', new.nota2semestre,
			', nota final: ', new.notafinal, ' para o aluno de cod: ', new.codaluno));
end;

create trigger tg5 after insert
on turma_aluno
for each row
begin
	update turma set turma.quantidadealunos=turma.quantidadealunos+1 where codturma=new.codturma;	
end;

create trigger tg6 after insert
on disciplina
for each row
begin
	update professor set professor.quantdisciplinas=professor.quantdisciplinas+1 where professor.codprofessor=new.codprofessor;	
end;

create trigger tg7 before insert
on nota
for each row
begin
	set new.notafinal=(new.nota1semestre+new.nota2semestre)/2;
end;

create trigger tg8 after insert
on nota
for each row
begin
	insert into log (descricaolog) values (concat ('A disciplina, o codigo do alunoe a nota são, respectivamente: ', 
		new.coddisciplina,', ',new.codaluno, ' ', new.notafinal));
end;